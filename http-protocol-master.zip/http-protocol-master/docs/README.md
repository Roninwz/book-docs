---
home: true
heroImage: logo.svg
actionText: 开始 →
actionLink: /notes/base/01-HTTP的前世今生
features:
- title: 简洁至上
  details: 追求重点和难点,剔除陈旧的知识。
- title: 清晰易懂
  details: 提炼精髓要点
- title: 紧跟热点
  details: 当下热点技术一网打尽。
footer: MIT Licensed | Copyright © 2019-present  blog.poetries.top
---
