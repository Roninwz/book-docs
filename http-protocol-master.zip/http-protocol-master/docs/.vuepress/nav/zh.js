module.exports = [
  {
    text: 'node笔记',
    link: '/notes/',
  },
]
