# 算法思维系列

本章包含一些常用的算法技巧，比如前缀和、回溯思想、位操作、双指针、如何正确书写二分查找等等。

欢迎关注我的公众号 labuladong，查看全部文章：

![labuladong二维码](../pictures/table_qr2.jpg)
![labuladong二维码](../pictures/qrcode.jpg)